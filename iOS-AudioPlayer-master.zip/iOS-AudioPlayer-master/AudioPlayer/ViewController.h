//
//  ViewController.h
//  AudioPlayer
//
//  Created by apple on 2017/2/10.
//  Copyright © 2017年 xiaokai.zhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

