//
//  AppDelegate.h
//  FFmpegDecoder
//
//  Created by apple on 2017/2/8.
//  Copyright © 2017年 xiaokai.zhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

